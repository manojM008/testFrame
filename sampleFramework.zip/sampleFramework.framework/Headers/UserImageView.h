//
//  UserImageView.h
//  GetActive
//
//  Created by Manoj Shetty on 20/02/17.
//  Copyright © 2017 2mpower. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserImageDetailView.h"

@interface UserImageView : UIView
@property (strong, nonatomic) UIImageView *imageView;

- (id)initWithFrame:(CGRect)frame imageURL:(NSString*) url isRounded:(BOOL) _isRounded;

- (void) setUserId:(NSString*) userId buddyIconType:(BuddyIconType) _buddyIconType;
- (void) reset;
@end
