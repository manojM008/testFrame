//
//  UserImageDetailView.h
//  GetActive
//
//  Created by Manoj Shetty on 20/02/17.
//  Copyright © 2017 2mpower. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger,BuddyIconType) {
    AddBuddy = 0,
    Buddy,
    RequestSent,
    None
} ;

@interface UserImageDetailView : UIView

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIButton *buddyIcon;
- (id)initWithFrame:(CGRect)frame url:(NSString *) url andBuddyIconBuddy:(BuddyIconType) buddyIconType;
- (IBAction)didPressAddBuddy:(id)sender;
- (void) setUserId:(NSString*) userID;
- (IBAction)dismissView:(id)sender;

@end
