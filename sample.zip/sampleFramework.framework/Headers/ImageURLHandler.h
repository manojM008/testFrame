//
//  ImageURLHandler.h
//  SampleCode
//
//  Created by Manoj Shetty on 30/08/17.
//  Copyright © 2017 Mac User. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ImageURLHandler : NSObject
+ (void) loadImageView:(UIImageView*) imageView withURL:(NSString*) url andPlaceHolderImage:(UIImage*) image isForcedReload:(BOOL) isForcedReload;
@end
